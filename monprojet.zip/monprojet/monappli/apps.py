from django.apps import AppConfig


class MonappliConfig(AppConfig):
    name = 'monappli'
